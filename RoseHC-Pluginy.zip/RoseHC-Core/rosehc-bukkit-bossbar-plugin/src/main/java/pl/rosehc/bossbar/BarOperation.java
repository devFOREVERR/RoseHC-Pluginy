package pl.rosehc.bossbar;

public enum BarOperation {
  ADD,
  REMOVE,
  UPDATE_PCT,
  UPDATE_NAME,
  UPDATE_STYLE,
  UPDATE_PROPERTIES
}
