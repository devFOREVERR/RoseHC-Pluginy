package pl.rosehc.bossbar;

public enum BarColor {
  PINK,
  BLUE,
  RED,
  GREEN,
  YELLOW,
  PURPLE,
  WHITE,
  NONE
}