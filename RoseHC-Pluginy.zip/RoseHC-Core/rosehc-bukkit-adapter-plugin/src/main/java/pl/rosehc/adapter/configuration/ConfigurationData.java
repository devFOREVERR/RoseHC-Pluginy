package pl.rosehc.adapter.configuration;

import java.io.File;

public class ConfigurationData {

  public transient File file;
}
