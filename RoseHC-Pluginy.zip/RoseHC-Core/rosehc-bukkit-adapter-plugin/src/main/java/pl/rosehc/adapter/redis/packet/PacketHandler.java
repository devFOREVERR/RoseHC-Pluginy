package pl.rosehc.adapter.redis.packet;

/**
 * @author stevimeister on 17/06/2021
 **/
public interface PacketHandler {

}
