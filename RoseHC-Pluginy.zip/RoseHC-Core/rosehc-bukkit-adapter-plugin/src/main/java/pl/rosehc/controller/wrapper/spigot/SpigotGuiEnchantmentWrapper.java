package pl.rosehc.controller.wrapper.spigot;

public final class SpigotGuiEnchantmentWrapper {

  public String enchantmentName;
  public int enchantmentLevel;
}
