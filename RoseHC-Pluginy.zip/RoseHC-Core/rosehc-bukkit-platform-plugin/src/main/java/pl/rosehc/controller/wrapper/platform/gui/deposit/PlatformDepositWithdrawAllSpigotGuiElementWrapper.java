package pl.rosehc.controller.wrapper.platform.gui.deposit;

import pl.rosehc.controller.wrapper.spigot.DefaultSpigotGuiElementWrapper;

public final class PlatformDepositWithdrawAllSpigotGuiElementWrapper extends
    DefaultSpigotGuiElementWrapper {

}
