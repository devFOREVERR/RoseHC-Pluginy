package pl.rosehc.controller.wrapper.platform.gui.other;

import pl.rosehc.controller.wrapper.spigot.SpigotGuiElementWrapper;

public final class PlatformCrowbarTakeoverSpigotGuiElementWrapper extends SpigotGuiElementWrapper {

  {
    this.material = null;
  }
}
