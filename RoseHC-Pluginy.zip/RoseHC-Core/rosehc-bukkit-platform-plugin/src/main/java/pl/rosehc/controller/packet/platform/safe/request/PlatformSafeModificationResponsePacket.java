package pl.rosehc.controller.packet.platform.safe.request;

import pl.rosehc.adapter.redis.callback.CallbackPacket;
import pl.rosehc.adapter.redis.packet.PacketHandler;

public final class PlatformSafeModificationResponsePacket extends CallbackPacket {

  @Override
  public void handle(final PacketHandler ignored) {
  }
}
