package pl.rosehc.platform.end.session;

public enum EndPortalPointEditingSessionStatus {

  FIRST_POINT_ALREADY_SET, SECOND_POINT_ALREADY_SET,
  FIRST_POINT_SUCCESSFULLY_SET, SECOND_POINT_SUCCESSFULLY_SET
}
